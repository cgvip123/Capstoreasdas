package com.cg.capstore.bean;

import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;

public class Address 
{
	@Id
	@Column(name="mobileNo",length=10)
	private String mobileNo;
	@Column(name="pincode",length=6)
	private String pincode;
	@Column(name="houseNo",length=10)
	private String houseNo;
	@Column(name="area",length=20)
	private String area;
	@Column(name="city",length=20)
	private String city;
	@Column(name="state",length=30)
	private String state;
	@Column(name="landmark",length=50)
	private String landmark;
	@Column(name="name",length=50)
	private String name;
	@Column(name="alternate_mob",length=10)
	private String alternateMobileNo;
	@Enumerated(EnumType.STRING)
	
	private enum addressType{HOME,WORK};
	
}
