package com.cg.capstore.bean;

public enum AddressType 
{
	HOME,WORK
}
