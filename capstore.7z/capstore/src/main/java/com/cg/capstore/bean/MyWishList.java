package com.cg.capstore.bean;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

public class MyWishList 
{
	private int wishId;
	private List<Long> productId;
	
	public MyWishList()
	{
		super();
	}
	
	public MyWishList(int wishId, List<Long> productId)
	{
		super();
		this.wishId = wishId;
		this.productId = productId;
	}
	
	public int getWishId() {
		return wishId;
	}
	public void setWishId(int wishId) {
		this.wishId = wishId;
	}
	public List<Long> getProductId() {
		return productId;
	}
	public void setProductId(List<Long> productId) {
		this.productId = productId;
	}
	
	
	@Override
	public String toString() {
		return "MyWishList [wishId=" + wishId + ", productId=" + productId + "]";
	}
	
	

}
