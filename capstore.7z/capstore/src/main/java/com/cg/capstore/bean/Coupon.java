package com.cg.capstore.bean;

import java.time.LocalDate;

public class Coupon
{	
	private long couponId;
	private String couponCode;
	private String description;
	private boolean applied;
	private LocalDate expiryDate;
}
