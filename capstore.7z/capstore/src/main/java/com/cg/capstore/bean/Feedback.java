package com.cg.capstore.bean;

public class Feedback
{
	private long feedbackId;
	private String description;
	private Product product;
}
