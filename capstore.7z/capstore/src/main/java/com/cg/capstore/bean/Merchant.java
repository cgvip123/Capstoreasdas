package com.cg.capstore.bean;

import java.util.List;

public class Merchant 
{
	private long merchantId;
	private String merchantName;
	private enum merchantType{};
	private String email;
	private String mobile;
	private String password;
	private Address merchantAddress;
	private List<Product> products;
 	
}
