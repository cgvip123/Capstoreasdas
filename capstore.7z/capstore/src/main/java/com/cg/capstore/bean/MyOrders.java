package com.cg.capstore.bean;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

public class MyOrders
{
	@Id
	@Column(name="orderId",length=10)
	private long orderId;

	@OneToMany(cascade=CascadeType.ALL,mappedBy="myorders")
	private List<Product> product;
	
	@Column(name="purchaseDate",length=50)
	@Temporal(TemporalType.DATE)
	private Date purchaseDate;
	
	private Address deliveryAddress;
	private LocalDate DeliveryDate;
	private  Invoice  invoice;	
	private String orderStatus;
	private Double subTotal;
	
	private Customer customerOrd;
	
	public MyOrders() 
	{
		super();
	}
	
	
	
	public MyOrders(long orderId, List<Product> product, LocalDate purchaseDate, Address deliveryAddress,
			LocalDate deliveryDate, Invoice invoice, String orderStatus, Double subTotal, Customer customerOrd) {
		super();
		this.orderId = orderId;
		this.product = product;
		this.purchaseDate = purchaseDate;
		this.deliveryAddress = deliveryAddress;
		DeliveryDate = deliveryDate;
		this.invoice = invoice;
		this.orderStatus = orderStatus;
		this.subTotal = subTotal;
		this.customerOrd = customerOrd;
	}



	public long getorderId() {
		return orderId;
	}
	public void setorderId(long orderId) {
		this.orderId = orderId;
	}
	
	
	
	
	public List<Product> getProduct() {
		return product;
	}



	public void setProduct(List<Product> product) {
		this.product = product;
	}



	public LocalDate getPurchaseDate() {
		return purchaseDate;
	}
	public void setPurchaseDate(LocalDate purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	public Address getDeliveryAddress() {
		return deliveryAddress;
	}
	public void setDeliveryAddress(Address deliveryAddress) {
		this.deliveryAddress = deliveryAddress;
	}
	public LocalDate getDeliveryDate() {
		return DeliveryDate;
	}
	public void setDeliveryDate(LocalDate deliveryDate) {
		DeliveryDate = deliveryDate;
	}
	public Invoice getTransDetails() {
		return invoice;
	}
	public void setTransDetails(Invoice transDetails) {
		this.invoice = transDetails;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	public Double getSubTotal() {
		return subTotal;
	}
	public void setSubTotal(Double subTotal) {
		this.subTotal = subTotal;
	}



	@Override
	public String toString() {
		return "MyOrders [orderId=" + orderId + ", product=" + product + ", purchaseDate=" + purchaseDate
				+ ", deliveryAddress=" + deliveryAddress + ", DeliveryDate=" + DeliveryDate + ", invoice=" + invoice
				+ ", orderStatus=" + orderStatus + ", subTotal=" + subTotal + ", customerOrd=" + customerOrd + "]";
	}
	
	
	
	
	
	
}
