package com.cg.capstore.bean;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


public class MyOrders
{
	private long myoOrderId;
	private List<Long > prodId;
	private LocalDate purchaseDate;
	private Address deliveryAddress;
	private LocalDate DeliveryDate;
	private  Invoice  invoice;	
	private String orderStatus;
	private Double subTotal;
	
	public MyOrders() 
	{
		super();
	}
	
	public MyOrders(long myoOrderId, List<Long> prodId, LocalDate purchaseDate, Address deliveryAddress,
			LocalDate deliveryDate, Invoice transDetails, String orderStatus, Double subTotal)
	{
		super();
		this.myoOrderId = myoOrderId;
		this.prodId = prodId;
		this.purchaseDate = purchaseDate;
		this.deliveryAddress = deliveryAddress;
		DeliveryDate = deliveryDate;
		this.invoice = transDetails;
		this.orderStatus = orderStatus;
		this.subTotal = subTotal;
	}
	
	public long getMyoOrderId() {
		return myoOrderId;
	}
	public void setMyoOrderId(long myoOrderId) {
		this.myoOrderId = myoOrderId;
	}
	public List<Long> getProdId() {
		return prodId;
	}
	public void setProdId(List<Long> prodId) {
		this.prodId = prodId;
	}
	public LocalDate getPurchaseDate() {
		return purchaseDate;
	}
	public void setPurchaseDate(LocalDate purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	public Address getDeliveryAddress() {
		return deliveryAddress;
	}
	public void setDeliveryAddress(Address deliveryAddress) {
		this.deliveryAddress = deliveryAddress;
	}
	public LocalDate getDeliveryDate() {
		return DeliveryDate;
	}
	public void setDeliveryDate(LocalDate deliveryDate) {
		DeliveryDate = deliveryDate;
	}
	public Invoice getTransDetails() {
		return invoice;
	}
	public void setTransDetails(Invoice transDetails) {
		this.invoice = transDetails;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	public Double getSubTotal() {
		return subTotal;
	}
	public void setSubTotal(Double subTotal) {
		this.subTotal = subTotal;
	}
	
	
	@Override
	public String toString() {
		return "MyOrders [myoOrderId=" + myoOrderId + ", prodId=" + prodId + ", purchaseDate=" + purchaseDate
				+ ", DeliveryDate=" + DeliveryDate + ", InvoiceId=" + invoice + ", orderStatus=" + orderStatus
				+ ", subTotal=" + subTotal + "]";
	}
	
	
	
}
