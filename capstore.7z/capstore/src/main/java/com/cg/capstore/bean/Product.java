package com.cg.capstore.bean;

import java.util.List;

import javax.persistence.ManyToOne;

public class Product
{
	private long prodId;
	private String name;
	private String size;
	private int quantity;
	private double rating;
	private Merchant merchant;
	private double price;
	private String prodCategory;
	private List<Image> prodImages;
	private double prodDiscount;
	private List<Coupon> prodCoupon;
	private Feedback prodFeedback;
	
	@ManyToOne
	private MyOrders myorders;
}
