package com.cg.capstore.bean;
import java.awt.Image;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Id;

public class Product
{
	private long prodId;
	private String name;
	private String size;
	private int quantity;
	private double rating;
	private Merchant merchant;
	private double price;
	private String prodCategory;
	private List<Image> prodImages;
	private double prodDiscount;
	private List<Coupon> prodCoupon;
	private Feedback prodFeedback;
}
