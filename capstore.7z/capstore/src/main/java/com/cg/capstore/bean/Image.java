package com.cg.capstore.bean;

public class Image 
{
	private String url;

	public Image()
	{
		super();
	}

	public Image(String url)
	{
		super();
		this.url = url;
	}

	public String getUrl()
	{
		return url;
	}

	public void setUrl(String url) 
	{
		this.url = url;
	}

	@Override
	public String toString()
	{
		return "Image [url=" + url + "]";
	}
	
	
}
