package com.cg.capstore.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

public class Invoice
{
	private long invoiceId;

	private enum paymentMethod{CASH_ON_DELIVERY , NETBANKING , CARD};
	private long transactionId;
	
	public Invoice() 
	{
		super();
	}
	
	public long getInvoiceId() 
	{
		return invoiceId;
	}



	public void setInvoiceId(long invoiceId)
	{
		this.invoiceId = invoiceId;
	}



	public long getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}
	public Invoice(long transactionId) {
		super();
		this.transactionId = transactionId;
	}

	@Override
	public String toString() {
		return "Invoice [invoiceId=" + invoiceId + ", transactionId=" + transactionId + "]";
	}
	
	
}
